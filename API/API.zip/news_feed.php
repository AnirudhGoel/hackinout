<?php

require_once("HTTP/Client.php");

$url = "https://api.havenondemand.com/1/api/sync/querytextindex/v1?text=health+india&ignore_operators=false&indexes=news_eng&promotion=false&total_results=false&apikey=c7b3fa19-7afa-43a0-a7bc-034c3b192f5c";

$data = "--form \"text=health india\" --form \"ignore_operators=false\" --form \"indexes=news_eng\" --form \"promotion=false\" --form \"total_results=false\" --form \"apikey=c7b3fa19-7afa-43a0-a7bc-034c3b192f5c";

HTTP_Client::post ( string $url , mixed $data , boolean $preEncoded = false);

?>